@echo off
title Multi-Core Load Balancing Scheduler
echo =============================================
echo     🚀 Starting Multi-Core Scheduler...
echo =============================================
echo.
streamlit run app.py
pause